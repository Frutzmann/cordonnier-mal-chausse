# Shooting Framework — Claude Code Remote Control

## Infos vidéo

- **Titre A :** Claude Code sur ton téléphone — l'IA bosse sans toi
- **Titre B :** J'ai testé Claude Code Remote Control (en vrai)
- **Croyance fil rouge :** "L'IA, c'est un truc de développeur collé à son écran"
- **Format :** 70% face cam / 30% screen recording
- **Durée cible :** 7–8 minutes
- **Source de preuve :** Niveau 1 — propre utilisation + données tierces (Anthropic, VentureBeat)
- **SPCL :** Status ✅ / Power ✅ / Credibility ✅ / Likeness ⚠️ partiel

---

## Ordre de tournage

> **IMPORTANT : Le Bloc 1 (Ouverture) se tourne EN DERNIER.**
> Tu auras fait toute la démo, tu sauras quel moment est le plus impressionnant, et tu le filmes comme hook d'ouverture.

1. Bloc 2 — C'est quoi Claude Code Remote
2. Bloc 3 — Setup live
3. Bloc 4 — Démo (3-4 tests)
4. Bloc 5 — Limites et sécurité
5. Bloc 6 — Verdict + CTA
6. **Bloc 1 — Ouverture (tourné en dernier)**

---

## BLOC 1 — Ouverture / Hook (0:00–0:45)

**Format :** Face cam + insert téléphone
**Objectif :** Montrer le RÉSULTAT avant d'expliquer quoi que ce soit. Comme Nate Herk — on commence par la fin.

### Ce que tu montres :

- Toi sur ton téléphone, tu envoies une instruction
- Ton ordi exécute en temps réel
- Le viewer voit le résultat avant de comprendre comment

### Ce que tu dis (direction, pas script mot à mot) :

> "Anthropic vient de sortir Remote Control pour Claude Code. En gros : tu pilotes ton agent IA depuis ton téléphone. Je l'ai testé — voilà comment ça marche, ce que ça change vraiment, et les limites."

### 🔒 Tips rétention :

- **Payoff immédiat :** Le viewer voit le résultat en < 10 secondes. Pas d'intro, pas de logo, pas de "salut c'est François"
- **Boucle ouverte :** Le viewer voit que ça marche mais ne sait pas COMMENT → il reste pour comprendre
- **Pattern interrupt :** L'insert du téléphone avec le code qui s'exécute casse le rythme visuel dès la première seconde

---

## BLOC 2 — C'est quoi Claude Code Remote (0:45–2:15)

**Format :** Face cam + inserts visuels (doc, annonce X, schéma)
**Objectif :** Expliquer Remote Control (PAS Claude Code — on part du principe que le viewer connaît) et ce que ça rend possible.

### Ce que tu couvres :

1. **Remote Control c'est quoi :** une feature sortie hier qui connecte ton app Claude (iOS/Android/web) à ta session Claude Code locale. Ton téléphone = télécommande pour ton agent IA.

2. **Ce que ça permet concrètement :**
   - Lancer tes agents sur ton ordi, partir, continuer à les piloter depuis ton smartphone
   - Monitorer ce que fait ton agent en temps réel
   - Envoyer de nouvelles instructions à la volée
   - Tout reste synchronisé entre tous tes appareils

3. **La nuance clé :** ça tourne toujours en LOCAL sur ta machine. Tes fichiers, tes MCP servers, ton contexte projet — tout reste chez toi. Le téléphone c'est juste une fenêtre. ≠ Claude Code on the web qui tourne dans le cloud d'Anthropic.

4. **Pourquoi c'est un shift :** avant tu étais collé à ton terminal. Les bidouilleurs faisaient du SSH + tmux + Tailscale pour bricoler un accès mobile. Maintenant c'est une commande, un QR code, c'est fait.

### Ce que tu peux montrer à l'écran (inserts rapides) :

- L'annonce officielle de Claude sur X/Threads
- La page de la doc
- Un schéma simple : ordi ←→ Anthropic API ←→ téléphone

### 🔒 Tips rétention :

- **Rythme visuel :** Alterne face cam / insert toutes les 15-20 secondes. Ne reste JAMAIS 30 secondes sur le même plan
- **Boucle ouverte :** À la fin du bloc, tease la démo : "OK assez parlé, je vais te montrer ce que ça donne en vrai"
- **Pas de jargon non expliqué :** Si tu dis "MCP servers", explique en une phrase ("des outils externes que Claude Code peut utiliser — genre ton Google Calendar, ton n8n, etc.")

---

## BLOC 3 — Setup en live (2:15–3:45)

**Format :** Screen recording + face cam en picture-in-picture
**Objectif :** Montrer le setup complet. Le viewer doit se dire "c'est VRAIMENT simple."

### Séquence :

1. **Terminal ouvert, naviguer vers un vrai projet**
   > "Je suis dans [nom du projet]. Je tape une seule commande..."

2. **Taper `claude remote-control`**
   - Le QR code apparaît
   - Commenter : montrer que c'est littéralement UNE commande

3. **Scanner le QR code avec le téléphone**
   - Filmer TOI en train de scanner (pas un screencast du scan)
   - Montrer la connexion qui s'établit sur le téléphone

4. **Montrer la session active sur les deux écrans**
   - Le terminal sur l'ordi
   - L'interface sur le téléphone
   - Pointer que c'est la même session

5. **Si ça bug → le montrer**
   - Simon Willison et d'autres ont eu un bug d'auth au premier lancement
   - "Premier essai, ça marche pas. Je me déconnecte, `/login`, je retente... et là c'est bon."
   - L'authenticité d'un vrai test > un tuto léché

### Alternative : `/rc` depuis une session existante

- Si tu es déjà dans une session Claude Code, tu peux taper `/rc` ou `/remote-control`
- La session existante + son historique deviennent accessibles depuis le téléphone
- Montrer les deux options

### 🔒 Tips rétention :

- **Speed :** Le setup doit paraître RAPIDE. Si t'as un moment de chargement, coupe ou accélère en post-prod (×2 ou ×4)
- **Face cam PiP :** Ta réaction en miniature dans le coin pendant le screen recording maintient le lien humain
- **Payoff du bloc :** Le moment où le téléphone se connecte = moment de satisfaction. Marque-le : petite pause, "et voilà, je suis connecté"

---

## BLOC 4 — Démo : tests réels (3:45–6:15)

**Format :** Screen recording + face cam PiP + alternance face cam entre les tests
**Objectif :** Montrer ce qui est VRAIMENT possible. C'est le cœur de la vidéo.

### Test 1 — Message simple depuis le téléphone (45 sec)

- Envoie une instruction basique depuis ton tel
- Ex : "Liste les fichiers de ce projet et explique ce que fait chaque fichier"
- Montre l'ordi qui exécute en temps réel
- Commente : "Je ne touche pas mon clavier. Tout se passe depuis mon téléphone."

### Test 2 — Un vrai task sur un vrai projet (60-90 sec)

- Lance quelque chose de concret sur un de TES projets
- Montre que Claude a accès à ton filesystem local, tes fichiers, tout ton contexte
- Plus c'est concret et réel, mieux c'est. Pas un hello world.
- Face cam entre les moments d'exécution pour commenter ce qui se passe

### Test 3 — Synchro bidirectionnelle (30-45 sec)

- Tape quelque chose sur ton ordi → ça apparaît sur le tel
- Tape sur ton tel → ça apparaît sur l'ordi
- Montre que c'est la MÊME conversation, synchronisée
- "Je peux passer d'un device à l'autre sans rien perdre"

### Test 4 — MCP servers depuis le téléphone (45-60 sec)

- SI tes MCP sont configurés (n8n, Google Calendar, Gmail)
- Montre que Remote Control y a aussi accès depuis le tel
- Ex : "Regarde mes événements Google Calendar de demain" ou un truc via ton n8n
- C'est LE truc technique que personne ne montre encore
- Si ça ne marche pas ou si tu n'as pas de MCP → skip, pas grave

### Entre chaque test : face cam rapide (10-15 sec)

- Ta réaction honnête
- Ce qui t'impressionne ou te déçoit
- Transition vers le test suivant

### 🔒 Tips rétention :

- **Varier le rythme visuel toutes les 30 secondes.** Screen → face cam → split screen → insert téléphone. Ne reste JAMAIS sur le même plan trop longtemps
- **Chaque test = mini boucle ouverte.** "Maintenant je vais tester un truc..." → exécution → résultat. Ouvre, ferme, ouvre, ferme.
- **Couper les temps morts.** Si Claude met 20 secondes à exécuter, accélère en post-prod ou commente par-dessus
- **Le moment "wow" :** Identifie-le pendant le tournage. C'est celui que tu utiliseras pour filmer le Bloc 1 ensuite

---

## BLOC 5 — Ce qu'il faut savoir : limites et sécurité (6:15–7:15)

**Format :** Face cam + bullet points visuels à l'écran
**Objectif :** Crédibilité. Tu montres que tu ne vends pas du rêve.

### Les points à couvrir :

1. **Prérequis :**
   - Plan Pro ($20/mois) ou Max ($100-200/mois) obligatoire
   - Pas de clé API — authentification via `/login`
   - Pas encore dispo sur Team ou Enterprise

2. **Ce qui doit rester allumé :**
   - Ton ordi doit rester allumé
   - Le terminal doit rester ouvert
   - Connexion internet requise — déconnexion après ~10 minutes sans réseau

3. **Limitations actuelles :**
   - Une seule session remote à la fois
   - On ne peut pas DÉMARRER une nouvelle session depuis le téléphone — seulement continuer une session existante
   - C'est un research preview — il y a des bugs

4. **⚠️ SÉCURITÉ :**
   - NE PAS partager l'URL de session ou le QR code
   - N'importe qui avec le lien peut accéder à tes fichiers locaux
   - Pas de 2FA sur la connexion remote
   - Insister : "Quand vous avez fini, tuez la session"

5. **Remote Control vs Claude Code on the web :**
   - Remote Control = LOCAL (tes fichiers, tes MCP, ton contexte)
   - Claude Code web = CLOUD (sandbox Anthropic, pas d'accès à tes fichiers locaux)
   - Les deux ont leur utilité, mais Remote Control c'est pour le vrai travail sur tes projets

### 🔒 Tips rétention :

- **Ce bloc peut tuer la rétention s'il est trop long.** Max 60 secondes. Rapide, factuel, visuel.
- **Bullet points à l'écran** pendant que tu parles — le viewer peut lire ET écouter
- **Finir sur un hook vers le verdict :** "OK, maintenant que tu sais tout — voilà ce que j'en pense vraiment"

---

## BLOC 6 — Verdict honnête + CTA (7:15–8:00)

**Format :** Face cam
**Objectif :** Ton avis franc. Le viewer est resté jusqu'ici, il mérite une conclusion claire.

### Direction :

> "Est-ce que c'est game changer ? Honnêtement, c'est en research preview — y'a des bugs, des limites. Mais la direction est claire : on va vers un monde où ton agent IA tourne en permanence et tu le pilotes de n'importe où. Et ça, c'est nouveau."

> "Ce qui m'a le plus impressionné c'est [ton vrai moment fort de la démo]. Ce qui me manque encore c'est [ta vraie limite]."

### Double CTA :

**CTA soft :**
> "Si tu veux voir comment j'utilise Claude Code et l'IA pour automatiser des process concrets — facturation, relances, reporting — j'ai un lien en description."

**CTA hard :**
> "Et si t'as déjà des process à automatiser et que tu veux qu'on en parle — lien Calendly juste en dessous, 30 minutes."

### 🔒 Tips rétention :

- **Tu n'as plus besoin de retenir — tu dois SATISFAIRE.** Le viewer qui est là à 7:15 est un fan potentiel. Donne-lui un verdict clair et un CTA.
- **Pas de traîne.** Verdict → CTA → "À la prochaine." C'est fini. 30-45 secondes max.

---

## Tips rétention globaux

### Les 5 règles de survie

1. **Premier payoff avant 30 secondes.** Le résultat visible avant toute explication.
2. **Varier le rythme visuel toutes les 20-30 secondes.** Face cam → screen → insert → split screen → face cam. JAMAIS le même plan plus de 30 sec.
3. **Boucles ouvertes en cascade.** Chaque bloc ouvre une question que le suivant résout. La fin d'un bloc tease le suivant.
4. **Couper tout ce qui ne sert pas le viewer.** Chaque seconde doit apporter de l'info, de l'émotion ou de la curiosité. Si ça sert ton ego et pas le viewer → coupe.
5. **Les moments de chargement = ennemis de la rétention.** Accélère en post-prod (×2, ×4) ou commente par-dessus.

### Transitions entre blocs

| De → Vers | Transition |
|-----------|-----------|
| Bloc 1 → Bloc 2 | "Bon, je t'explique ce que c'est et pourquoi c'est un shift" |
| Bloc 2 → Bloc 3 | "OK assez parlé, je vais te montrer comment on l'installe" |
| Bloc 3 → Bloc 4 | "Setup terminé. Maintenant on teste pour de vrai" |
| Bloc 4 → Bloc 5 | "Avant de te donner mon verdict — les trucs à savoir" |
| Bloc 5 → Bloc 6 | "OK, maintenant que tu sais tout — voilà ce que j'en pense" |

### Checklist post-tournage

- [ ] Le Bloc 1 a été tourné EN DERNIER avec le vrai meilleur moment de la démo
- [ ] Aucun plan ne dure plus de 30 secondes sans changement visuel
- [ ] Les temps de chargement/exécution sont accélérés
- [ ] Chaque bloc se termine par un tease du suivant
- [ ] Le CTA mentionne des process concrets (facturation, relances, reporting)
- [ ] Durée totale : 7-8 minutes
